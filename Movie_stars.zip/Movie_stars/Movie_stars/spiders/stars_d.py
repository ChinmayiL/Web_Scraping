# -*- coding: utf-8 -*-
import scrapy
from  scrapy import Spider
from scrapy.http import Request
from scrapy.loader import ItemLoader
from Movie_stars.items import MovieStarsItem


class StarsSpider(scrapy.Spider):
    name = 'stars_d'
    allowed_domains = ['thefamouspeople.com']
    start_urls = ['https://www.thefamouspeople.com/indian-film-theater-personalities.php']

    def parse(self,response):
        stars=response.xpath('.//*[@id="relatedDiv"]/div/div/a/@href').extract()
        for star in stars:
            stars_url= response.urljoin(star)
            yield Request(stars_url, callback=self.parse_stars)

    def parse_stars(self,response):
        l = ItemLoader(item=MovieStarsItem(), response=response)
        name= response.css('h1::text').extract_first()
        url= response.url
        images= response.xpath('//div[@class="item active"]/img/@src').extract_first()
       
        image_urls= response.xpath('//div[@class="item active"]/img/@src').extract_first()
        image_urls = image_urls.replace('//', 'https://')

        about_section=response.xpath('//*[@id="intro"]/text()').extract_first()



        yield { 'Name':name,
                'URL' : url,
                'Images': images,
                'Image URL': image_urls,
                'About_Section' : about_section }

        return l.load_item()
