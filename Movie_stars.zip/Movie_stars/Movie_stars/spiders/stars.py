# -*- coding: utf-8 -*-
import scrapy 
from  scrapy import Spider
from scrapy.http import Request
from scrapy.loader import ItemLoader
from Movie_stars.items import MovieStarsItem


#def quick_facts(response,value):
 #   return response.xpath('//span[@class="quickfactstitle"]/[text()="'+ value +'"] /string(following-sibling::a/)').extract_first()
    

class StarsSpider(scrapy.Spider):
    name = 'stars'
    allowed_domains = ['thefamouspeople.com']
    start_urls = ['https://www.thefamouspeople.com/indian-film-theater-personalities.php']

    def parse(self,response):
        stars=response.xpath('.//*[@id="relatedDiv"]/div/div/a/@href').extract()
        for star in stars:
            stars_url= response.urljoin(star)
            yield Request(stars_url, callback=self.parse_stars)

    def parse_stars(self,response):
        l = ItemLoader(item=MovieStarsItem(), response=response)
        name= response.css('h1::text').extract_first()
        url= response.url
        images= response.xpath('//div[@class="item active"]/img/@src').extract_first()
       
        image_urls= response.xpath('//div[@class="item active"]/img/@src').extract_first()
        image_urls = image_urls.replace('//', 'https://')

        about_section=response.xpath('//*[@id="intro"]/text()').extract_first()
        
        l.add_value('name', name)
        l.add_value('url', url)
        l.add_value('image_urls', image_urls)
        l.add_value('about_section' , about_section)

        return l.load_item()

